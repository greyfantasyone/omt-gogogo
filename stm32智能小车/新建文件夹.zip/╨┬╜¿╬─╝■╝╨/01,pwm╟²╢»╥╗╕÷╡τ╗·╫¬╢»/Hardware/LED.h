#ifndef __LED_H
#define __LED_H
void LED_Init();
void LED1_Turn();
void LED2_Turn();
#endif