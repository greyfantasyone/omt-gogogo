#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "PWM.h"

int main(void)
{ 
	
	
	Go_Ahead();
	while (1)
	{
		
	}
}