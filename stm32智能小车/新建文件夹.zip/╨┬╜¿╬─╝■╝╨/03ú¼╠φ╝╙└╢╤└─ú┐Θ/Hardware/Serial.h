#ifndef __SERIAL_H
#define __SERIAL_H
void Serial_Init(void);
#endif